import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { deleteTodo, toggleTodo, updateTodo } from '../redux/todoSlice';

const TodoItem = ({ todo }) => {
  const dispatch = useDispatch();
  const [editMode, setEditMode] = useState(false);
  const [updatedText, setUpdatedText] = useState(todo.text);

  const handleUpdate = () => {
    if (updatedText.trim()) {
      dispatch(updateTodo({ id: todo.id, text: updatedText }));
      setEditMode(false);
    }
  };

  return (
    <li className={`todo ${todo.completed ? 'done' : ''}`}>
      {editMode ? (
        <>
          <input value={updatedText} onChange={e => setUpdatedText(e.target.value)} />
          <button onClick={handleUpdate}>Save</button>
        </>
      ) : (
        <>
          <span onClick={() => dispatch(toggleTodo(todo.id))}>
            {todo.text}
          </span>
          <div>
            <button onClick={() => setEditMode(true)}>Edit</button>
            <button onClick={() => dispatch(deleteTodo(todo.id))}>Delete</button>
          </div>
        </>
      )}
    </li>
  );
};

export default TodoItem;
